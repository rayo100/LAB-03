package dominio;

public class Iglu {

}
